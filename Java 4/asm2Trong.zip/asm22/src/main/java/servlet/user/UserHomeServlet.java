package servlet.user;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Books;
import repository.BooksRepository;

import java.io.IOException;
import java.util.List;
@WebServlet("/user/books")

public class UserHomeServlet extends HttpServlet {

    private BooksRepository booksRepo = new BooksRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Lấy keyword tìm kiếm từ query param
        String keyword = req.getParameter("keyword");

        List<Books> books;
        if (keyword != null && !keyword.trim().isEmpty()) {
            books = booksRepo.searchByTitleOrAuthor(keyword.trim());
        } else {
            books = booksRepo.findAll();
        }

        // Đưa danh sách sách vào attribute để JSP truy xuất
        req.setAttribute("books", books);
        req.setAttribute("keyword", keyword);

        // Chuyển tiếp tới trang JSP hiển thị danh sách sách
        req.getRequestDispatcher("/user/homeuser.jsp").forward(req, resp);
    }
}
