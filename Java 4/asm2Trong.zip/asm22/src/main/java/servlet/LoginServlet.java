package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Users;
import repository.UsersRepository;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UsersRepository usersRepo = new UsersRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Hiển thị trang login (cả admin & student dùng chung trang login này hoặc khác cũng được)
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Users user = usersRepo.findByEmailAndPassword(email, password);
        if (user == null) {
            request.setAttribute("error", "Email hoặc mật khẩu không đúng");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        if (user != null) {
            // Lưu thông tin vào session
            HttpSession session = request.getSession();
            session.setAttribute("currentUser", user);

            // Chuyển hướng theo role
            if ("ADMIN".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect(request.getContextPath() + "/admin/homeadmin.jsp");
            } else if ("STUDENT".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect(request.getContextPath() + "/user/homeuser.jsp");
            } else {
                // Nếu role khác hoặc không xác định, có thể redirect về login hoặc trang lỗi
                response.sendRedirect(request.getContextPath() + "/login.jsp?error=Unauthorized");
            }
        } else {
            // Đăng nhập sai
            request.setAttribute("error", "Email hoặc mật khẩu không đúng");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
}
