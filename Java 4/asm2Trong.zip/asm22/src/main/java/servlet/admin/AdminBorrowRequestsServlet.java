package servlet.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Books;
import model.BorrowRequests;
import repository.BooksRepository;
import repository.BorrowRequestsRepository;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/borrow_requests")
public class AdminBorrowRequestsServlet extends HttpServlet {

    private BorrowRequestsRepository borrowRequestsRepo = new BorrowRequestsRepository();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<BorrowRequests> requests = borrowRequestsRepo.findAll();
        req.setAttribute("requests", requests);
        req.getRequestDispatcher("/admin/borrow_requests.jsp").forward(req, resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        String requestIdStr = req.getParameter("requestId");

        if (requestIdStr == null || action == null) {
            resp.sendRedirect(req.getContextPath() + "/admin/borrow_requests");
            return;
        }

        int requestId = Integer.parseInt(requestIdStr);
        BorrowRequests request = borrowRequestsRepo.findById(requestId);

        if (request == null || !"PENDING".equals(request.getStatus())) {
            // Yêu cầu không tồn tại hoặc đã xử lý
            resp.sendRedirect(req.getContextPath() + "/admin/borrow_requests");
            return;
        }

        if ("approve".equals(action)) {
            // Kiểm tra số lượng sách
            Books book = request.getBook();
            if (book.getQuantity() > 0) {
                // Giảm số lượng sách
                book.setQuantity(book.getQuantity() - 1);
                // Cập nhật sách
                BooksRepository booksRepo = new BooksRepository();
                booksRepo.update(book);

                // Cập nhật trạng thái yêu cầu thành APPROVED
                request.setStatus("APPROVED");
                borrowRequestsRepo.update(request);
            } else {
                // Không thể duyệt vì hết sách, có thể set lỗi thông báo
                req.setAttribute("error", "Không thể duyệt vì sách đã hết.");
                doGet(req, resp);
                return;
            }
        } else if ("reject".equals(action)) {
            // Cập nhật trạng thái yêu cầu thành REJECTED
            request.setStatus("REJECTED");
            borrowRequestsRepo.update(request);
        }

        resp.sendRedirect(req.getContextPath() + "/admin/borrow_requests");
    }

}
