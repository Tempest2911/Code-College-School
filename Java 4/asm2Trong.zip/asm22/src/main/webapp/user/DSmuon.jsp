<%--
  Created by IntelliJ IDEA.
  User: My Computer
  Date: 11/08/2025
  Time: 7:59 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page session="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Danh sách yêu cầu mượn sách</title>
    <style>
        table {
            border-collapse: collapse;
            width: 90%;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #eee;
        }
        .status-pending {
            color: orange;
            font-weight: bold;
        }
        .status-approved {
            color: green;
            font-weight: bold;
        }
        .status-rejected {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
<h2>Danh sách yêu cầu mượn sách của bạn</h2>

<c:if test="${not empty message}">
    <p style="color:green">${message}</p>
</c:if>
<c:if test="${not empty error}">
    <p style="color:red">${error}</p>
</c:if>

<table>
    <thead>
    <tr>
        <th>Tiêu đề sách</th>
        <th>Tác giả</th>
        <th>Trạng thái</th>
    </tr>
    </thead>
    <tbody>
    <c:choose>
        <c:when test="${not empty requests}">
            <c:forEach var="req" items="${requests}">
                <tr>
                    <td>${req.book.title}</td>
                    <td>${req.book.author}</td>
                    <td>
                        <c:choose>
                            <c:when test="${req.status == 'PENDING'}">
                                <span class="status-pending">Chờ duyệt</span>
                            </c:when>
                            <c:when test="${req.status == 'APPROVED'}">
                                <span class="status-approved">Đã duyệt</span>
                            </c:when>
                            <c:when test="${req.status == 'REJECTED'}">
                                <span class="status-rejected">Từ chối</span>
                            </c:when>
                            <c:otherwise>
                                <span>${req.status}</span>
                            </c:otherwise>
                        </c:choose>
                    </td>
                </tr>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <tr>
                <td colspan="3">Bạn chưa gửi yêu cầu mượn sách nào.</td>
            </tr>
        </c:otherwise>
    </c:choose>
    </tbody>
</table>

<br>
<a href="${pageContext.request.contextPath}/user/books">Quay lại trang chủ</a>
</body>
</html>
