<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page session="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Trang người dùng</title>
</head>
<body>
<h2>Chào mừng bạn: ${currentUser.name}</h2>

<p>Đây là trang dành cho sinh viên (user).</p>

<a href="${pageContext.request.contextPath}/user/books">Xem danh sách sách</a><br>
<a href="${pageContext.request.contextPath}/user/borrow_requests">Yêu cầu mượn của tôi</a><br>
<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>

<hr>

<h3>Danh sách sách</h3>

<form method="get" action="${pageContext.request.contextPath}/user/books">
    <input type="text" name="keyword" placeholder="Tìm kiếm theo tiêu đề hoặc tác giả" value="${param.keyword}" />
    <button type="submit">Tìm kiếm</button>
</form>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
    <tr>
        <th>Tiêu đề</th>
        <th>Tác giả</th>
        <th>Số lượng còn</th>
        <th>Hành động</th>
    </tr>
    </thead>
    <tbody>
    <c:choose>
        <c:when test="${not empty books}">
            <c:forEach var="book" items="${books}">
                <tr>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td>${book.quantity}</td>
                    <td>
                        <c:choose>
                            <c:when test="${book.quantity > 0}">
                                <form method="post" action="${pageContext.request.contextPath}/user/borrow_requests">
                                    <input type="hidden" name="bookId" value="${book.id}" />
                                    <button type="submit">Mượn</button>
                                </form>
                            </c:when>
                            <c:otherwise>
                                Hết sách
                            </c:otherwise>
                        </c:choose>
                    </td>
                </tr>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <tr>
                <td colspan="4">Không có sách nào.</td>
            </tr>
        </c:otherwise>
    </c:choose>
    </tbody>
</table>

</body>
</html>
