<%--
  Created by IntelliJ IDEA.
  User: My Computer
  Date: 11/08/2025
  Time: 8:28 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<html>
<head>
    <title>Quản lý yêu cầu mượn sách</title>
</head>
<body>
<h2>
    Danh sách yêu cầu mượn sách
    &nbsp;&nbsp;
    <a href="${pageContext.request.contextPath}/admin/homeadmin.jsp" style="font-size:14px;">← Quay lại trang chủ</a>
</h2>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
    <tr>
        <th>Tên sinh viên</th>
        <th>Tên sách</th>
        <th>Ngày gửi yêu cầu</th>
        <th>Trạng thái</th>
        <th>Hành động</th>
    </tr>
    </thead>
    <tbody>
    <c:forEach var="req" items="${requests}">
        <tr>
            <td>${req.user.name}</td>
            <td>${req.book.title}</td>
            <td>${req.requestDate}</td>
            <td>
                <c:choose>
                    <c:when test="${req.status == 'PENDING'}">Chờ duyệt</c:when>
                    <c:when test="${req.status == 'APPROVED'}">Đã duyệt</c:when>
                    <c:when test="${req.status == 'REJECTED'}">Từ chối</c:when>
                    <c:otherwise>${req.status}</c:otherwise>
                </c:choose>
            </td>
            <td>
                <c:if test="${req.status == 'PENDING'}">
                    <form method="post" action="${pageContext.request.contextPath}/admin/borrow_requests" style="display:inline-block;">
                        <input type="hidden" name="requestId" value="${req.id}" />
                        <input type="hidden" name="action" value="approve" />
                        <button type="submit">Phê duyệt</button>
                    </form>
                    <form method="post" action="${pageContext.request.contextPath}/admin/borrow_requests" style="display:inline-block;">
                        <input type="hidden" name="requestId" value="${req.id}" />
                        <input type="hidden" name="action" value="reject" />
                        <button type="submit">Từ chối</button>
                    </form>
                </c:if>
            </td>
        </tr>
    </c:forEach>
    </tbody>

</table>

</body>
</html>
