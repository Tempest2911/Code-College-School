<%--
  Created by IntelliJ IDEA.
  User: My Computer
  Date: 11/08/2025
  Time: 8:52 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page session="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<html>
<head>
    <title>Quản lý sách</title>
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
        form {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #888;
            width: 400px;
            background-color: #f9f9f9;
        }
        form input[type="text"],
        form input[type="number"] {
            width: 100%;
            padding: 6px;
            margin: 6px 0 12px 0;
            box-sizing: border-box;
        }
        form button {
            padding: 6px 12px;
        }
        .action-links a {
            margin-right: 10px;
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
<h2>Quản lý sách</h2>

<a href="${pageContext.request.contextPath}/admin/homeadmin.jsp">Quay lại trang chủ Admin</a>

<c:if test="${not empty error}">
    <div class="error">${error}</div>
</c:if>

<table>
    <thead>
    <tr>
        <th>ID</th>
        <th>Tiêu đề</th>
        <th>Tác giả</th>
        <th>Số lượng</th>
        <th>Hành động</th>
    </tr>
    </thead>
    <tbody>
    <c:forEach var="book" items="${books}">
        <tr>
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.quantity}</td>
            <td class="action-links">
                <a href="${pageContext.request.contextPath}/admin/books?action=edit&id=${book.id}">Sửa</a>
                <a href="${pageContext.request.contextPath}/admin/books?action=delete&id=${book.id}"
                   onclick="return confirm('Bạn có chắc muốn xóa sách này?');">Xóa</a>
            </td>
        </tr>
    </c:forEach>
    <c:if test="${empty books}">
        <tr>
            <td colspan="5">Chưa có sách nào.</td>
        </tr>
    </c:if>
    </tbody>
</table>

<h3><c:choose>
    <c:when test="${not empty editBook}">Chỉnh sửa sách</c:when>
    <c:otherwise>Thêm sách mới</c:otherwise>
</c:choose></h3>

<form method="post" action="${pageContext.request.contextPath}/admin/books">
    <input type="hidden" name="id" value="${editBook.id}"/>

    <label for="title">Tiêu đề:</label><br/>
    <input type="text" id="title" name="title" value="${editBook.title}" required/><br/>

    <label for="author">Tác giả:</label><br/>
    <input type="text" id="author" name="author" value="${editBook.author}" required/><br/>

    <label for="quantity">Số lượng:</label><br/>
    <input type="number" id="quantity" name="quantity" min="0" value="${editBook.quantity}" required/><br/>

    <button type="submit"><c:choose>
        <c:when test="${not empty editBook}">Cập nhật</c:when>
        <c:otherwise>Thêm mới</c:otherwise>
    </c:choose></button>

    <c:if test="${not empty editBook}">
        <a href="${pageContext.request.contextPath}/admin/books" style="margin-left: 10px;">Hủy</a>
    </c:if>
</form>

</body>
</html>
