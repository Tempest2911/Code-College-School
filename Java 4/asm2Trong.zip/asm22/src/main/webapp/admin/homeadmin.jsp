<%--
  Created by IntelliJ IDEA.
  User: My Computer
  Date: 11/08/2025
  Time: 7:30 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page session="true" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Trang quản trị Admin</title>
</head>
<body>
<h2>Chào mừng Admin: ${currentUser.name}</h2>

<p>Đây là trang quản trị dành riêng cho Admin.</p>

<a href="${pageContext.request.contextPath}/admin/books">Quản lý sách</a><br>
<a href="${pageContext.request.contextPath}/admin/borrow_requests">Quản lý yêu cầu mượn</a><br>
<a href="${pageContext.request.contextPath}/logout">Đăng xuất</a>
</body>
</html>
