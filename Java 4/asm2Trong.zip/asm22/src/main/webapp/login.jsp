<%--
  Created by IntelliJ IDEA.
  User: My Computer
  Date: 11/08/2025
  Time: 7:19 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Đăng nhập hệ thống</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            padding: 20px;
        }
        .login-container {
            background: white;
            max-width: 400px;
            margin: 50px auto;
            padding: 30px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        input[type=email], input[type=password] {
            width: 100%;
            padding: 8px 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .error-message {
            color: red;
            margin-top: 15px;
            text-align: center;
        }
        button {
            width: 100%;
            margin-top: 25px;
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Đăng nhập hệ thống</h2>
    <form action="${pageContext.request.contextPath}/login" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required placeholder="Nhập email" />

        <label for="password">Mật khẩu:</label>
        <input type="password" id="password" name="password" required placeholder="Nhập mật khẩu" />

        <div style="margin-top: 20px; display: flex; gap: 10px;">
            <button type="submit" style="flex: 1;">Đăng nhập</button>
            <button type="button" style="flex: 1; background-color: #28a745; border: none; color: white; cursor: pointer;"
                    onclick="window.location.href='${pageContext.request.contextPath}/register'">Đăng ký</button>
        </div>
    </form>


    <c:if test="${not empty error}">
        <div class="error-message">${error}</div>
    </c:if>
</div>

</body>
</html>
