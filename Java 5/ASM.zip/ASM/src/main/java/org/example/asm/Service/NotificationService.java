package org.example.asm.Service;

import org.example.asm.DTO.TaskDTO;
import org.example.asm.Model.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // Gửi task đến tất cả staff
    public void sendTaskNotification(Task task, String action) {
        TaskDTO dto = new TaskDTO(task, action);
        messagingTemplate.convertAndSend("/topic/tasks", dto);

        // Nếu muốn gửi riêng cho staff được assign
        if (task.getAssignedTo() != null) {
            messagingTemplate.convertAndSendToUser(
                    task.getAssignedTo().getUsername(), // username staff
                    "/queue/tasks",                     // queue riêng staff
                    dto
            );
        }
    }
}
