package org.example.demau.Controller;

import org.example.demau.Model.ChucVu;
import org.example.demau.Model.NhanVien;
import org.example.demau.Repository.ChucVuRepository;
import org.example.demau.Repository.NhanVienRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/nhan-vien")
public class NhanVienController {

    @Autowired
    NhanVienRepository nhanVienRepository;

    @Autowired
    ChucVuRepository chucVuRepository;

    @ModelAttribute("listChucVu")
    public List<ChucVu> getListChucVu() {
        return chucVuRepository.findAll();
    }

    @GetMapping
    public String list(Model model) {

        model.addAttribute("nhanVien", nhanVienRepository.findAll());
        return "nhanVien";
    }

    @PostMapping("/add")
    public String add(Model model) {
        model.addAttribute("nhanVien", new NhanVien());
        return "nhanVien";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, Model model) {
        model.addAttribute("nhanVien", nhanVienRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid id:" + id)));
        return "nhanVien";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Integer id) {
        nhanVienRepository.deleteById(id);
        return "redirect:/nhan-vien";
    }

    @GetMapping("/save")
    public String save(@ModelAttribute("nhanVien") NhanVien nhanVien) {
        nhanVienRepository.save(nhanVien);
        return "redirect:/nhan-vien";
    }



}
