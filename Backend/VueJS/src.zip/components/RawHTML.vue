<template>
    <div>
        <h2 v-html="htmlContent"></h2>
    </div>
</template>

<script setup>
    const htmlContent = `<u>Xin chào cách bạn!</u>`;
</script>