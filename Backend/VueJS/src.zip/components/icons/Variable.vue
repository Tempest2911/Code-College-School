<script setup>

 const count = 0
 const message = 'Hello, Vue 3!'

</script>
