<template>
    <h1>Welcome to VueJS Course</h1>
</template>